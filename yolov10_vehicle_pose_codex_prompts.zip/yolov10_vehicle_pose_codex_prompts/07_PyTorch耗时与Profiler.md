请为训练完成的 YOLOv10n Vehicle Pose 实现严格的 PyTorch 耗时测试与性能分析。

## 前置输入

自动选择或通过参数指定：

- checkpoint
- model config
- 固定真实验证图片列表
- device
- imgsz
- batch size

默认：

- batch=1
- imgsz=640
- warmup=100
- iterations=1000
- device=cuda:0（CUDA 可用时）
- 固定输入 shape
- 固定随机种子

## 必须注意的 YOLOv10 问题

官方仓库提示：非导出 PyTorch 路径可能在推理阶段额外执行 `v10Detect` 的 `cv2` 和 `cv3` 操作，导致测速偏慢。

因此必须分别测试并清楚命名：

1. `torch_original`：仓库原始 PyTorch eval 路径。
2. `torch_one2one_only`：只执行推理需要的 one-to-one 路径。
3. `forward_only`：不含 decode/postprocess。
4. `forward_decode`：模型 forward + 关键点/框 decode。
5. `end_to_end`：读图、预处理、H2D、forward、decode、D2H。

不得只报告一个模糊的“inference time”。

## Benchmark 模式

至少支持：

- CPU FP32
- CUDA FP32 eager
- CUDA FP16 autocast eager
- CUDA FP16 `model.half()` eager
- CUDA FP32 channels_last
- CUDA FP16 channels_last
- CUDA FP32 torch.compile
- CUDA FP16 torch.compile

`torch.compile` 可用时测试：

- default
- reduce-overhead
- max-autotune

编译冷启动、首次运行和稳定态必须分开报告。

## 正确计时

GPU model-only 使用：

- `torch.cuda.Event(enable_timing=True)`
- warmup
- 测量前后 `torch.cuda.synchronize()`
- `model.eval()`
- `torch.inference_mode()`

不能用单纯的 `time.time()` 测异步 CUDA forward。

端到端 CPU 墙钟时间可使用高精度 wall-clock，但必须在正确位置同步 GPU。

不要每次迭代做不必要的 synchronize；若需要每样本分位数，可采用分批事件或经过验证的测量方式，说明实现。

## 分阶段耗时

至少统计：

- file read
- image decode
- resize/letterbox
- tensor conversion
- H2D
- model forward
- bbox/keypoint decode
- postprocess
- D2H
- visualization（单独，不计入主端到端）
- total end-to-end

## 数据

两类输入：

### Synthetic

- 固定随机 tensor
- 用于纯模型稳定比较

### Real

- `reports/training/fixed_eval_images.txt`
- 不同实验使用完全相同的图像与顺序
- 预热图与正式图分开

## 输出统计

每种模式输出：

- count
- mean
- std
- min
- max
- P50
- P90
- P95
- P99
- FPS（注明换算方式）
- peak allocated CUDA memory
- peak reserved CUDA memory
- 参数量
- checkpoint 大小
- 输入 shape
- PyTorch/CUDA/GPU/驱动
- CPU 线程设置
- 是否开启 cudnn benchmark
- precision
- compile mode
- channels_last
- 原始模式或 one2one-only

结果保存为：

- JSON
- CSV
- Markdown

## 数值正确性

所有加速模式与 FP32 eager one2one-only 基线比较：

- 输出目标数量
- box 最大绝对误差
- confidence 最大绝对误差
- keypoint 坐标最大绝对误差
- visibility 最大绝对误差
- NaN/Inf
- 完整验证集 bbox 与关键点指标变化

阈值配置化。不得只比较一张图后宣称精度无损。

## torch.profiler

实现 profiler 脚本并输出：

- CPU total/self time 前 30
- CUDA total/self time 前 30
- 调用次数
- 输入 shape
- 显存
- trace 文件
- graph break（torch.compile 时）
- Python 热点
- CPU-GPU 同步点
- `.item()`、`.cpu()`、`.numpy()` 触发同步
- 重复 sigmoid/reshape/permute/contiguous
- 重复 anchor/grid 创建
- 大量小 kernel
- 未使用的 one-to-many 分支
- 逐目标或逐关键点 Python 循环

## 稳定性

- 至少运行 3 轮独立 benchmark。
- 报告各轮差异。
- 明显抖动时检查 GPU 频率、温度、后台负载和数据缓存状态。
- 不删除异常值；解释异常值。
- 当前机器不是最终前端设备时，明确标记结果仅代表当前设备。

## 交付

新增或按仓库规范实现：

- `benchmarks/benchmark_torch.py`
- `benchmarks/profile_torch.py`
- `benchmarks/compare_outputs.py`
- `scripts/benchmark_torch.sh`
- `scripts/profile_torch.sh`

生成：

- `reports/benchmark/07_environment.json`
- `reports/benchmark/07_results.json`
- `reports/benchmark/07_results.csv`
- `reports/benchmark/07_report.md`
- `reports/benchmark/07_correctness_report.md`
- `reports/benchmark/profiler/`
- `reports/benchmark/07_profiler_analysis.md`

最后明确当前最大瓶颈及其证据，不要直接开始结构优化。
