# YOLOv10 车辆关键点项目：Codex 提示词使用顺序

## 官方资源

- YOLOv10 官方仓库：https://github.com/THU-MIG/yolov10.git
- YOLOv10n 官方权重：https://github.com/THU-MIG/yolov10/releases/download/v1.1/yolov10n.pt
- CarFusion 项目页：https://www.cs.cmu.edu/~ILIM/projects/IM/CarFusion/
- CarFusion 转换仓库：https://github.com/dineshreddy91/carfusion_to_coco.git
- CarFusion 数据访问申请表：https://forms.gle/FCUcbt3jD1hB6ja57

## 重要限制

CarFusion 的公开转换仓库不直接包含完整数据下载器。官方说明要求先填写访问申请表，获批后取得 `download_carfusion.py`。Codex 可以自动执行已获授权的下载脚本，但不能替你填写表单、绕过授权或从不明镜像抓取数据。

## 推荐执行顺序

1. `01_仓库与环境初始化.md`
2. `02_CarFusion授权下载与检查.md`
3. `03_仓库审计与设计方案.md`
4. `04_YOLOv10车辆关键点实现.md`
5. `05_数据转换与质量检查.md`
6. `06_训练与精度评测.md`
7. `07_PyTorch耗时与Profiler.md`
8. `08_耗时精度联合优化.md`
9. `09_最终验收与交付.md`

每次只把一个文件的内容交给 Codex。前一阶段验收通过后再进入下一阶段。

## 建议启动方式

在 Codex 中打开你希望放置项目的父目录，然后先使用 `/plan`，再粘贴当前阶段提示词。

## 全局原则

- 不允许在没有验证的情况下宣称完成。
- 不允许伪造数据、指标、训练日志或 benchmark 结果。
- 不允许绕过数据集访问控制。
- 修改前先读取真实仓库代码，不按假想目录硬改。
- 每个阶段必须生成报告，并列出执行过的命令。
- 保留 YOLOv10 原检测能力，新增车辆关键点能力不能破坏现有检测任务。
- 所有性能优化必须同时做精度回归。
- benchmark 默认 `batch=1`，同时报告 model-only 与 end-to-end。
- 训练和 benchmark 使用的 Git commit、配置、权重和数据划分必须可追溯。
