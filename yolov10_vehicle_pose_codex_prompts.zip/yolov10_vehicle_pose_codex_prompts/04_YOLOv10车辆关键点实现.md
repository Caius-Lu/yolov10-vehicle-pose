请按照已经通过审查的设计文档实现 YOLOv10n 车辆关键点检测。先读取：

- `reports/design/03_repository_audit.md`
- `reports/design/03_vehicle_pose_design.md`
- `reports/design/03_change_list.md`

如果文档与真实代码不一致，以真实代码为准，并记录偏差。

## 核心要求

### 1. 模型

- 任务：车辆框 + 14 个车辆关键点。
- `kpt_shape = [14, 3]`。
- Pose Head 只使用部署友好的卷积、BN、SiLU、reshape、permute、concat 等基础算子。
- 禁止 Transformer、Self-Attention、ROIAlign、全连接关键点头和自定义 CUDA。
- 关键点 Head 中间通道数与深度必须可配置。
- 默认候选：
  - `pose_head_channels: 96`
  - `pose_head_depth: 2`
- 支持 P3/P4/P5。
- 推理必须支持固定 shape 的向量化 decode，禁止逐目标 Python 循环。

### 2. YOLOv10 双分支

必须基于实际 assigner 输出，保证关键点 GT 与匹配的 vehicle GT 一致。

训练阶段：

- one-to-many 分支计算检测和关键点损失。
- one-to-one 分支计算检测和关键点损失。
- 两分支权重可配置。
- 不允许仅凭 bbox 索引猜测关键点对应关系。

推理阶段：

- 默认只输出 one-to-one 分支。
- 提供明确的 PyTorch `one2one_only` 或等价推理路径。
- 保留原始模式，便于做正确性与耗时对照。
- 两种路径的 one-to-one 输出必须在数值容差内一致。

### 3. Loss

优先复用已有实现；若不适用，最小新增。

总 Loss 包括：

- classification
- bbox regression
- DFL
- keypoint coordinate
- keypoint visibility

规则：

- `v=0`：未标注/无效，不参与坐标损失。
- `v=1`：已标注但遮挡，参与坐标损失和可见性监督。
- `v=2`：可见，参与坐标损失和可见性监督。
- 明确 visibility head 是二分类还是三分类；第一版优先部署简单、定义清晰的方案。
- Loss 权重全部配置化。
- 防止无目标 batch、全不可见关键点、极小 bbox 导致 NaN。

### 4. 配置

新增或按项目规范命名：

- YOLOv10n Vehicle Pose 模型配置
- CarFusion 数据配置
- Loss 配置
- benchmark 配置

不得硬编码绝对路径、GPU 编号和数据根目录。

### 5. 权重初始化

支持加载：

`weights/yolov10n.pt`

要求：

- Backbone、Neck 和兼容检测权重正常加载。
- 新增 Pose 参数合理初始化。
- 输出 loaded、missing、unexpected、shape mismatch 明细。
- 禁止用 `strict=False` 后静默忽略。

### 6. 测试

至少覆盖：

- 模型构建
- P3/P4/P5 输出 shape
- 14×3 输出
- batch=1 与 batch>1
- 空目标
- 单目标、多目标
- 全部关键点不可见
- 部分遮挡
- Loss backward
- 梯度 NaN/Inf
- one-to-many / one-to-one 关键点匹配
- 原始 PyTorch 与 one2one-only 输出一致性
- checkpoint 保存/加载
- CPU forward
- CUDA forward（环境可用时）
- ONNX 导出冒烟测试（环境可用时）

### 7. 不得做的事情

- 不得复制整套 Ultralytics 代码形成平行框架。
- 不得破坏原 Detect 模型。
- 不得为了通过测试返回假张量。
- 不得静默跳过失败测试。
- 不得使用随机指标声称训练有效。

## 验收

执行：

- 相关单元测试
- 原 YOLOv10 Detect 最小回归测试
- Vehicle Pose forward/backward 冒烟测试

生成：

- `reports/design/04_implementation_report.md`
- `reports/design/04_modified_files.md`
- `reports/design/04_test_results.md`

报告中给出实际训练、验证、推理命令模板，但本阶段不启动完整训练。
