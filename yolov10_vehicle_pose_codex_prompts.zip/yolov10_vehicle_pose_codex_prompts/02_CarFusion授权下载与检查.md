请完成 CarFusion 数据集的授权下载准备和自动下载。只能使用官方或用户明确授权的来源，不得绕过访问控制。

## 官方链接

项目页：
https://www.cs.cmu.edu/~ILIM/projects/IM/CarFusion/

官方转换仓库：
https://github.com/dineshreddy91/carfusion_to_coco.git

数据访问申请表：
https://forms.gle/FCUcbt3jD1hB6ja57

## 已知事实

公开的 `carfusion_to_coco` 仓库要求用户填写访问表，获批后得到 `download_carfusion.py`。该下载器通常不在公开 Git 仓库中。

## 目标目录

- 转换工具：`external/carfusion_to_coco`
- 原始数据：`datasets/CarFusion/raw`
- COCO 格式：`datasets/CarFusion/coco`
- 日志：`reports/data/`

## 操作步骤

### 1. 下载转换仓库

若目录不存在：

`git clone https://github.com/dineshreddy91/carfusion_to_coco.git external/carfusion_to_coco`

若已存在：

- 检查 remote URL。
- 记录 commit hash。
- 不覆盖本地改动。

### 2. 检查授权下载器

依次检查：

- `external/carfusion_to_coco/download_carfusion.py`
- 环境变量 `CARFUSION_DOWNLOADER`
- 当前项目根目录下用户可能放置的 `download_carfusion.py`

如果通过环境变量找到文件，将其复制到转换仓库前先记录来源路径和 SHA256。

### 3. 自动下载

只有在下载器存在时执行：

- 先阅读下载脚本，确认目标路径、依赖和是否会覆盖文件。
- 不记录或打印任何访问 token、Cookie、私密链接。
- 将数据下载到 `datasets/CarFusion/raw`，必要时通过参数、环境变量或最小补丁指定路径。
- 支持断点续传时启用断点续传。
- 下载失败时保留日志，不删除已完成文件。
- 禁止从未授权镜像自动下载。

如果官方脚本按其原始约定下载到别处，可创建安全的符号链接或写清楚真实路径，不要重复复制几十 GB 数据。

### 4. 下载器不存在时

不要假装成功，也不要用随机数据代替。

创建 `ACTION_REQUIRED_CARFUSION.md`，写明：

1. 打开访问表链接。
2. 获批后下载 `download_carfusion.py`。
3. 将文件放到：
   `external/carfusion_to_coco/download_carfusion.py`
4. 再次运行本阶段。
5. 不要把包含私密 token 的脚本提交到 Git。

随后可以完成转换仓库安装和目录准备，但必须将数据阶段标记为 `BLOCKED_BY_DATASET_AUTHORIZATION`。

### 5. 依赖与转换

当原始数据完整后：

- 根据转换仓库要求创建独立环境或在当前环境安装兼容依赖。
- 先阅读 `carfusion_coco_setup.sh`，检查其路径、删除操作和硬编码。
- 不直接运行危险的递归删除。
- 必要时做最小路径适配。
- 执行官方转换，输出到 `datasets/CarFusion/coco`。
- 记录转换命令和日志。

### 6. 基础完整性检查

至少统计：

- 图像文件数量
- 标注文件数量
- COCO JSON 是否可解析
- `images`、`annotations`、`categories` 数量
- 缺失图像
- 损坏图像
- 每个实例关键点数量
- visibility 值分布
- bbox 非法值
- 坐标越界
- 重复 image id / annotation id
- 数据磁盘占用

随机可视化 20 张，保存到 `reports/data/carfusion_preview/`。

## 验收输出

生成：

- `reports/data/02_carfusion_download_report.md`
- `reports/data/carfusion_inventory.json`
- `reports/data/carfusion_download.log`
- 若未授权：`ACTION_REQUIRED_CARFUSION.md`

报告必须明确状态之一：

- `READY`
- `BLOCKED_BY_DATASET_AUTHORIZATION`
- `DOWNLOAD_FAILED`
- `CONVERSION_FAILED`

未经授权不得继续完整训练。
